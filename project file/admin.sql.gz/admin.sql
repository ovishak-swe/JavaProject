-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2018 at 04:32 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit`
--

CREATE TABLE `audit` (
  `Audit_ID` varchar(10) NOT NULL,
  `Student_ID` varchar(20) NOT NULL,
  `Status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cgpa`
--

CREATE TABLE `cgpa` (
  `Student_Name` varchar(30) NOT NULL,
  `Student_ID` varchar(30) NOT NULL,
  `Depertment` varchar(20) NOT NULL,
  `Semister` varchar(15) NOT NULL,
  `Grade_algorithm` varchar(10) DEFAULT NULL,
  `Grade_database` varchar(10) DEFAULT NULL,
  `Grade_java` varchar(10) DEFAULT NULL,
  `Total_cgpa` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cgpa`
--

INSERT INTO `cgpa` (`Student_Name`, `Student_ID`, `Depertment`, `Semister`, `Grade_algorithm`, `Grade_database`, `Grade_java`, `Total_cgpa`) VALUES
('Ovi', '1', 'SWE', '4th', '3.5', '3.4', '4.0', '3.6666667'),
('ovishak', '3', 'swe', '4th', '3.5', '3.25', '3.00', '3.3333333'),
('sheble', '1911', 'swe', '4th', '4', '3.50', '3.75', ''),
('sheble', '1911', 'swe', '4th', '4', '3.50', '3.75', '3.9166667'),
('arnob', '12', 'swe', '4th', '3.25', '3.50', '3.25', '3.25'),
('akash', '4', 'swe', '4th', '3.50', '3.00', '2.75', '3.25'),
('Rony', '5', 'swe', '4th', '3.00', '3.00', '3.00', '3.0'),
('pritom', '16', 'swe', '4th', '4.00', '3.00', '3.25', '3.4166667');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Serial` int(10) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Serial`, `Username`, `Password`) VALUES
(1, 'sakib', 'sakib123');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `ID` int(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Gander` varchar(20) NOT NULL,
  `Date_of_Birth` varchar(20) NOT NULL,
  `E_mail` varchar(30) NOT NULL,
  `Mobile` varchar(30) NOT NULL,
  `Present_address` varchar(50) NOT NULL,
  `Permanent_address` varchar(50) NOT NULL,
  `Post_code` varchar(15) DEFAULT NULL,
  `Social_ID` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`ID`, `Name`, `Gander`, `Date_of_Birth`, `E_mail`, `Mobile`, `Present_address`, `Permanent_address`, `Post_code`, `Social_ID`) VALUES
(1, 'rony', 'male', '7th may 98', 'freter', '537484', 'dha', 'dha', '1206', 'rony'),
(2, 'rasel', 'male', '8-10-18', 'jhdsahd', '21323', 'jdididj', 'jdd', '344', '24345325');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.SystemColor;

public class Main_menu {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_menu window = new Main_menu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main_menu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.setBounds(100, 100, 602, 449);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAdminMenu = new JLabel("Admin Menu");
		lblAdminMenu.setForeground(Color.ORANGE);
		lblAdminMenu.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblAdminMenu.setBounds(20, 24, 172, 48);
		frame.getContentPane().add(lblAdminMenu);
		
		JButton btnStudentInformation = new JButton("Student Information Entry");
		btnStudentInformation.setForeground(Color.MAGENTA);
		btnStudentInformation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				New_student_from window = new New_student_from();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnStudentInformation.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnStudentInformation.setBounds(92, 96, 238, 36);
		frame.getContentPane().add(btnStudentInformation);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\antu\\Documents\\NetBeansProjects\\Student Information System\\src\\student\\information\\system\\images\\logout.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(431, 24, 124, 29);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("View All Records");
		btnNewButton_1.setForeground(Color.MAGENTA);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_record window = new View_record();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(92, 155, 238, 36);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnUpdateRecord = new JButton("Update Record");
		btnUpdateRecord.setForeground(Color.MAGENTA);
		btnUpdateRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		student_update window = new student_update();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnUpdateRecord.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnUpdateRecord.setBounds(92, 214, 238, 36);
		frame.getContentPane().add(btnUpdateRecord);
		
		JButton btnStudentCgpa = new JButton("Student CGPA");
		btnStudentCgpa.setForeground(Color.MAGENTA);
		btnStudentCgpa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cgpa window = new cgpa();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnStudentCgpa.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnStudentCgpa.setBounds(92, 282, 238, 36);
		frame.getContentPane().add(btnStudentCgpa);
		
		JButton btnViewCgpa = new JButton("View CGPA");
		btnViewCgpa.setForeground(Color.MAGENTA);
		btnViewCgpa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Show_CGPA window = new Show_CGPA();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnViewCgpa.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnViewCgpa.setBounds(92, 348, 238, 36);
		frame.getContentPane().add(btnViewCgpa);
		
		JLabel lblNewLabel = new JLabel("Profile");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(441, 85, 89, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("Users");
		btnNewButton_2.setForeground(Color.MAGENTA);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Users window = new Users();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(431, 128, 89, 32);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnAudit = new JButton("Audit");
		btnAudit.setForeground(Color.MAGENTA);
		btnAudit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Audit window = new Audit();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAudit.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAudit.setBounds(431, 179, 89, 32);
		frame.getContentPane().add(btnAudit);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\antu\\Documents\\NetBeansProjects\\Student Information System\\src\\student\\information\\system\\images\\bk3.jpg"));
		label.setBounds(0, -1, 586, 411);
		frame.getContentPane().add(label);
		frame.getContentPane().setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblAdminMenu, btnStudentInformation, btnNewButton, btnNewButton_1, btnUpdateRecord}));
	}
}

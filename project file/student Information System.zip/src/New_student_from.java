import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class New_student_from {

	private JFrame frame;
	private JTextField IDField;
	private JTextField nameField;
	private JTextField ganderField;
	private JTextField dobField;
	private JTextField emailField;
	private JTextField mobField;
	private JTextField addressField;
	private JTextField addressField_2;
	private JTextField pCodeField;
	private JTextField socialField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New_student_from window = new New_student_from();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public New_student_from() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 11));
		frame.getContentPane().setForeground(Color.BLACK);
		frame.setBounds(100, 100, 726, 480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblStudentFrom = new JLabel("Student From");
		lblStudentFrom.setForeground(Color.MAGENTA);
		lblStudentFrom.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblStudentFrom.setBounds(274, 22, 206, 46);
		frame.getContentPane().add(lblStudentFrom);
		
		JLabel lblId = new JLabel("ID");
		lblId.setForeground(Color.BLACK);
		lblId.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblId.setBounds(10, 93, 49, 19);
		frame.getContentPane().add(lblId);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblName.setBounds(10, 123, 49, 19);
		frame.getContentPane().add(lblName);
		
		JLabel lblDateOfBirth = new JLabel("Date of Birth");
		lblDateOfBirth.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDateOfBirth.setBounds(10, 183, 99, 19);
		frame.getContentPane().add(lblDateOfBirth);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblEmail.setBounds(10, 213, 99, 19);
		frame.getContentPane().add(lblEmail);
		
		JLabel lblMobileNo = new JLabel("Mobile No.");
		lblMobileNo.setForeground(Color.BLACK);
		lblMobileNo.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblMobileNo.setBounds(10, 243, 99, 19);
		frame.getContentPane().add(lblMobileNo);
		
		JLabel lblAddress = new JLabel("Present Address");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAddress.setBounds(10, 273, 135, 19);
		frame.getContentPane().add(lblAddress);
		
		JLabel lblGander = new JLabel("Gander");
		lblGander.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblGander.setBounds(10, 153, 99, 19);
		frame.getContentPane().add(lblGander);
		
		JLabel lblPermanentAddress = new JLabel("Permanent Address");
		lblPermanentAddress.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPermanentAddress.setBounds(10, 303, 159, 19);
		frame.getContentPane().add(lblPermanentAddress);
		
		JLabel lblPostCode = new JLabel("Post Code");
		lblPostCode.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPostCode.setBounds(10, 333, 109, 19);
		frame.getContentPane().add(lblPostCode);
		
		JLabel lblSocialId = new JLabel("Social ID");
		lblSocialId.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblSocialId.setBounds(10, 363, 109, 19);
		frame.getContentPane().add(lblSocialId);
		
		IDField = new JTextField();
		IDField.setBounds(261, 90, 167, 28);
		frame.getContentPane().add(IDField);
		IDField.setColumns(10);
		
		nameField = new JTextField();
		nameField.setColumns(10);
		nameField.setBounds(261, 120, 167, 28);
		frame.getContentPane().add(nameField);
		
		ganderField = new JTextField();
		ganderField.setColumns(10);
		ganderField.setBounds(261, 150, 167, 28);
		frame.getContentPane().add(ganderField);
		
		dobField = new JTextField();
		dobField.setColumns(10);
		dobField.setBounds(261, 180, 167, 28);
		frame.getContentPane().add(dobField);
		
		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(261, 210, 167, 28);
		frame.getContentPane().add(emailField);
		
		mobField = new JTextField();
		mobField.setColumns(10);
		mobField.setBounds(261, 240, 167, 28);
		frame.getContentPane().add(mobField);
		
		addressField = new JTextField();
		addressField.setColumns(10);
		addressField.setBounds(261, 270, 167, 28);
		frame.getContentPane().add(addressField);
		
		addressField_2 = new JTextField();
		addressField_2.setColumns(10);
		addressField_2.setBounds(261, 300, 167, 28);
		frame.getContentPane().add(addressField_2);
		
		pCodeField = new JTextField();
		pCodeField.setColumns(10);
		pCodeField.setBounds(261, 330, 167, 28);
		frame.getContentPane().add(pCodeField);
		
		socialField = new JTextField();
		socialField.setColumns(10);
		socialField.setBounds(261, 360, 167, 28);
		frame.getContentPane().add(socialField);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\antu\\Documents\\NetBeansProjects\\Student Information System\\src\\student\\information\\system\\images\\Save-icon.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO student_info(ID,Name,Gander,Date_of_birth,E_mail,Mobile,Present_address,Permanent_address,Post_code,Social_ID)VALUES(?,?,?,?,?,?,?,?,?,?)");
					stmnt.setString(1,IDField.getText());
					stmnt.setString(2,nameField.getText());
					stmnt.setString(3,ganderField.getText());
					stmnt.setString(4,dobField.getText());
					stmnt.setString(5,emailField.getText());
					stmnt.setString(6,mobField.getText());
					stmnt.setString(7,addressField.getText());
					stmnt.setString(8,addressField_2.getText());
					stmnt.setString(9,pCodeField.getText());
					stmnt.setString(10,socialField.getText());
					
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException g) {
					// TODO Auto-generated catch block
					g.printStackTrace();
				}
			
		}});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(493, 383, 120, 31);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main_menu window = new Main_menu();
				frame.setVisible(false);
				window.main(null);
			}
			
		});
		btnBack.setBounds(611, 45, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\antu\\Documents\\NetBeansProjects\\Student Information System\\src\\student\\information\\system\\images\\bk.jpg"));
		label.setBounds(0, 0, 700, 441);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(0, 0, 46, 14);
		frame.getContentPane().add(label_1);
	}

}

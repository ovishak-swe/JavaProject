import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class student_update {

	private JFrame frame;
	private JTextField IDField;
	private JTextField nameField;
	private JTextField ganderField;
	private JTextField dobField;
	private JTextField emailField;
	private JTextField mobField;
	private JTextField addressField;
	private JTextField addressField_2;
	private JTextField pCodeField;
	private JTextField socialField;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					student_update window = new student_update();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public student_update() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 726, 480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblStudentFrom = new JLabel("Student Information Update ");
		lblStudentFrom.setForeground(Color.BLUE);
		lblStudentFrom.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblStudentFrom.setBounds(197, 11, 324, 46);
		frame.getContentPane().add(lblStudentFrom);
		
		JLabel lblId = new JLabel("ID");
		lblId.setForeground(Color.MAGENTA);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblId.setBounds(10, 93, 49, 19);
		frame.getContentPane().add(lblId);
		
		JLabel lblName = new JLabel("Name");
		lblName.setForeground(Color.MAGENTA);
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblName.setBounds(10, 123, 49, 19);
		frame.getContentPane().add(lblName);
		
		JLabel lblDateOfBirth = new JLabel("Date of Birth");
		lblDateOfBirth.setForeground(Color.MAGENTA);
		lblDateOfBirth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDateOfBirth.setBounds(10, 183, 99, 19);
		frame.getContentPane().add(lblDateOfBirth);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setForeground(Color.MAGENTA);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail.setBounds(10, 213, 99, 19);
		frame.getContentPane().add(lblEmail);
		
		JLabel lblMobileNo = new JLabel("Mobile No.");
		lblMobileNo.setForeground(Color.MAGENTA);
		lblMobileNo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMobileNo.setBounds(10, 243, 99, 19);
		frame.getContentPane().add(lblMobileNo);
		
		JLabel lblAddress = new JLabel("Present Address");
		lblAddress.setForeground(Color.MAGENTA);
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAddress.setBounds(10, 273, 123, 19);
		frame.getContentPane().add(lblAddress);
		
		JLabel lblGander = new JLabel("Gander");
		lblGander.setForeground(Color.MAGENTA);
		lblGander.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblGander.setBounds(10, 153, 99, 19);
		frame.getContentPane().add(lblGander);
		
		JLabel lblPermanentAddress = new JLabel("Permanent Address");
		lblPermanentAddress.setForeground(Color.MAGENTA);
		lblPermanentAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPermanentAddress.setBounds(10, 303, 143, 19);
		frame.getContentPane().add(lblPermanentAddress);
		
		JLabel lblPostCode = new JLabel("Post Code");
		lblPostCode.setForeground(Color.MAGENTA);
		lblPostCode.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPostCode.setBounds(10, 333, 109, 19);
		frame.getContentPane().add(lblPostCode);
		
		JLabel lblSocialId = new JLabel("Social ID");
		lblSocialId.setForeground(Color.MAGENTA);
		lblSocialId.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSocialId.setBounds(10, 363, 109, 19);
		frame.getContentPane().add(lblSocialId);
		
		IDField = new JTextField();
		IDField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					con.createStatement();
					
					String sql="select * from student_info where ID=?";
					PreparedStatement pst= con.prepareStatement(sql);
					pst.setString(1,IDField.getText());
					ResultSet rs=pst.executeQuery();
					
					
					if(rs.next()) {
						//.setText(rs.getString("Username"));
						//.setText(rs.getString("Password"));
						
						nameField.setText(rs.getString("Name"));
						ganderField.setText(rs.getString("Date_of_Birth"));
						dobField.setText(rs.getString("Gander"));
						emailField.setText(rs.getString("E_mail"));
						mobField.setText(rs.getString("Mobile"));
						addressField.setText(rs.getString("Present_address"));
						addressField_2.setText(rs.getString("Permanent_address"));
						pCodeField.setText(rs.getString("Post_code"));
						socialField.setText(rs.getString("Social_ID"));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		IDField.setBounds(148, 90, 167, 28);
		frame.getContentPane().add(IDField);
		IDField.setColumns(10);
		
		nameField = new JTextField();
		nameField.setColumns(10);
		nameField.setBounds(148, 120, 167, 28);
		frame.getContentPane().add(nameField);
		
		ganderField = new JTextField();
		ganderField.setColumns(10);
		ganderField.setBounds(148, 150, 167, 28);
		frame.getContentPane().add(ganderField);
		
		dobField = new JTextField();
		dobField.setColumns(10);
		dobField.setBounds(148, 180, 167, 28);
		frame.getContentPane().add(dobField);
		
		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(148, 210, 167, 28);
		frame.getContentPane().add(emailField);
		
		mobField = new JTextField();
		mobField.setColumns(10);
		mobField.setBounds(148, 240, 167, 28);
		frame.getContentPane().add(mobField);
		
		addressField = new JTextField();
		addressField.setColumns(10);
		addressField.setBounds(148, 270, 167, 28);
		frame.getContentPane().add(addressField);
		
		addressField_2 = new JTextField();
		addressField_2.setColumns(10);
		addressField_2.setBounds(148, 300, 167, 28);
		frame.getContentPane().add(addressField_2);
		
		pCodeField = new JTextField();
		pCodeField.setColumns(10);
		pCodeField.setBounds(148, 330, 167, 28);
		frame.getContentPane().add(pCodeField);
		
		socialField = new JTextField();
		socialField.setColumns(10);
		socialField.setBounds(148, 360, 167, 28);
		frame.getContentPane().add(socialField);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main_menu window=new Main_menu();
				frame.setVisible(false);
				window.main(null);
				
			}
			
		});
		btnBack.setBounds(611, 45, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select * from student_info");
					ResultSet rs=pst.executeQuery("select * from student_info");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table.setModel(dtm);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		scrollPane.setBounds(325, 123, 375, 152);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i= table.getSelectedRow();
				TableModel model = table.getModel();
				IDField.setText(model.getValueAt(i,0).toString());
				nameField.setText(model.getValueAt(i,1).toString());
				ganderField.setText(model.getValueAt(i,2).toString());
				dobField.setText(model.getValueAt(i,3).toString());
				emailField.setText(model.getValueAt(i,4).toString());
				mobField.setText(model.getValueAt(i,5).toString());
				addressField.setText(model.getValueAt(i,6).toString());
				addressField_2.setText(model.getValueAt(i,7).toString());
				pCodeField.setText(model.getValueAt(i,8).toString());
				socialField.setText(model.getValueAt(i,9).toString());
				
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setForeground(Color.DARK_GRAY);
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					Statement st= connection.createStatement();
					
					//String query="UPDATE `login` SET `Username`='"+textField_1.getText()+"',`Password`='"+textField_2.getText()+"' WHERE `Serial`="+textField.getText();
					String query="UPDATE `student_info` SET `Name`='"+nameField.getText()+"',`Date_of_Birth`='"+dobField.getText()+"',`Gander`='"+ganderField.getText()+"',`E_mail`='"+emailField.getText()+"',`Mobile`='"+mobField.getText()+"',`Present_address`='"+addressField.getText()+"',`Permanent_address`='"+addressField_2.getText()+"',`Post_code`='"+pCodeField.getText()+"',`Social_ID`='"+socialField.getText()+"' WHERE `ID`="+IDField.getText();
					if((st.executeUpdate(query))==1) {
						
						JOptionPane.showMessageDialog(null,"Successful");
						
						
					}
						
					}
				 catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnUpdate.setBounds(325, 299, 89, 23);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setForeground(Color.DARK_GRAY);
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					Statement st= connection.createStatement();
					
					String query= "DELETE FROM `student_info` WHERE `ID`="+IDField.getText();
					if((st.executeUpdate(query))>1) {
						DefaultTableModel model=(DefaultTableModel)table.getModel();
						model.setRowCount(0);
						JOptionPane.showMessageDialog(null,"Successful");
					}
						
					}
				 catch (ClassNotFoundException g) {
					// TODO Auto-generated catch block
					g.printStackTrace();
				} catch (SQLException g) {
					// TODO Auto-generated catch block
					g.printStackTrace();
				}
			}
		});
		btnDelete.setBounds(325, 330, 89, 23);
		frame.getContentPane().add(btnDelete);
		
		JButton btnRefreshTable = new JButton("Refresh ");
		btnRefreshTable.setForeground(Color.GREEN);
		btnRefreshTable.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnRefreshTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select * from student_info");
					ResultSet rs=pst.executeQuery("select * from student_info");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnRefreshTable.setBounds(386, 95, 123, 23);
		frame.getContentPane().add(btnRefreshTable);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\antu\\Documents\\NetBeansProjects\\Student Information System\\src\\student\\information\\system\\images\\bk2.jpg"));
		label.setBounds(0, 0, 710, 430);
		frame.getContentPane().add(label);
	}
}

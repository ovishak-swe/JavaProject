

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Color;

public class cgpa {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	/**
	 * Launch the application.
	 */
	
	double a,b,c,d,f;
	private JTextField textField_7;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cgpa window = new cgpa();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public cgpa() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 15));
		frame.setBounds(100, 100, 731, 482);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Student Name");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(34, 57, 117, 26);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblStudentId = new JLabel("Student ID");
		lblStudentId.setForeground(Color.BLUE);
		lblStudentId.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblStudentId.setBounds(34, 100, 117, 26);
		frame.getContentPane().add(lblStudentId);
		
		textField = new JTextField();
		textField.setBounds(161, 57, 214, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(161, 105, 214, 26);
		frame.getContentPane().add(textField_1);
		
		JLabel lblNewLabel_1 = new JLabel("Depertment");
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(392, 65, 117, 18);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblSemister = new JLabel("Semister");
		lblSemister.setForeground(Color.BLUE);
		lblSemister.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblSemister.setBounds(392, 108, 117, 18);
		frame.getContentPane().add(lblSemister);
		
		textField_2 = new JTextField();
		textField_2.setBounds(500, 57, 145, 26);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(500, 105, 145, 26);
		frame.getContentPane().add(textField_3);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main_menu window = new Main_menu();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(600, 11, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		textField_4 = new JTextField();
		textField_4.setBounds(183, 213, 117, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(183, 261, 117, 20);
		frame.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(183, 314, 117, 20);
		frame.getContentPane().add(textField_6);
		
		JButton btnNewButton_1 = new JButton("Calculate");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//double i=Double.parseDouble(textField_4.getText());
				//double j=Double.parseDouble(textField_5.getText());
				//double k=Double.parseDouble(textField_6.getText());
				float m=Float.parseFloat(textField_4.getText());
				float n=Float.parseFloat(textField_5.getText());
				float o=Float.parseFloat(textField_6.getText());
				
				String l=String.valueOf((m+m+o)/3);
				textField_7.setText(l);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(420, 260, 117, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("Courses");
		lblNewLabel_2.setForeground(Color.BLUE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(70, 172, 81, 29);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Grade Point");
		lblNewLabel_3.setForeground(Color.BLUE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(194, 170, 117, 32);
		frame.getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton_2 = new JButton("Save");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/admin","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO CGPA(Student_name,Student_ID,Depertment,Semister,Grade_algorithm,Grade_database,Grade_java,Total_cgpa)VALUES(?,?,?,?,?,?,?,?)");
					stmnt.setString(1,textField.getText());
					stmnt.setString(2,textField_1.getText());
					stmnt.setString(3,textField_2.getText());
					stmnt.setString(4,textField_3.getText());
					stmnt.setString(5,textField_4.getText());
					stmnt.setString(6,textField_5.getText());
					stmnt.setString(7,textField_6.getText());
					stmnt.setString(8,textField_7.getText());
					
					
					
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successful");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException g) {
					// TODO Auto-generated catch block
					g.printStackTrace();
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(107, 380, 89, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_4 = new JLabel("CGPA");
		lblNewLabel_4.setForeground(Color.MAGENTA);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_4.setBounds(296, 11, 139, 31);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblTotalCgpa = new JLabel("Total CGPA");
		lblTotalCgpa.setForeground(Color.BLUE);
		lblTotalCgpa.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTotalCgpa.setBounds(392, 308, 97, 32);
		frame.getContentPane().add(lblTotalCgpa);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(484, 314, 81, 20);
		frame.getContentPane().add(textField_7);
		
		JLabel lblAlgorithm = new JLabel("Algorithm");
		lblAlgorithm.setForeground(Color.BLUE);
		lblAlgorithm.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAlgorithm.setBounds(63, 216, 88, 14);
		frame.getContentPane().add(lblAlgorithm);
		
		JLabel lblDatabase = new JLabel("Database");
		lblDatabase.setForeground(Color.BLUE);
		lblDatabase.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDatabase.setBounds(63, 264, 88, 14);
		frame.getContentPane().add(lblDatabase);
		
		JLabel lblJava = new JLabel("Java");
		lblJava.setForeground(Color.BLUE);
		lblJava.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblJava.setBounds(80, 315, 71, 14);
		frame.getContentPane().add(lblJava);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\antu\\Downloads\\black.jpg"));
		lblNewLabel_5.setBounds(0, 0, 715, 432);
		frame.getContentPane().add(lblNewLabel_5);
	}
}
